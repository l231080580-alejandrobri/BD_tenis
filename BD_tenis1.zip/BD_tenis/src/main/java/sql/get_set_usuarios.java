/*
package sql;


public class get_set_usuarios {

    int id_usu;
    String nombre_usu;
    String apellido_usu;
    String correo_usu;
    String contraseña_usu;
    String telefono_usu;
    String rol_usu;
    String fecha_registro_usu;

    public int getId_usu() {
        return id_usu;
    }

    public void setId_usu(int id_usu) {
        this.id_usu = id_usu;
    }

    public String getNombre_usu() {
        return nombre_usu;
    }

    public void setNombre_usu(String nombre_usu) {
        this.nombre_usu = nombre_usu;
    }

    public String getApellido_usu() {
        return apellido_usu;
    }

    public void setApellido_usu(String apellido_usu) {
        this.apellido_usu = apellido_usu;
    }

    public String getCorreo_usu() {
        return correo_usu;
    }

    public void setCorreo_usu(String correo_usu) {
        this.correo_usu = correo_usu;
    }

    public String getContraseña_usu() {
        return contraseña_usu;
    }

    public void setContraseña_usu(String contraseña_usu) {
        this.contraseña_usu = contraseña_usu;
    }

    public String getTelefono_usu() {
        return telefono_usu;
    }

    public void setTelefono_usu(String telefono_usu) {
        this.telefono_usu = telefono_usu;
    }

    public String getRol_usu() {
        return rol_usu;
    }

    public void setRol_usu(String rol_usu) {
        this.rol_usu = rol_usu;
    }

    public String getFecha_registro_usu() {
        return fecha_registro_usu;
    }

    public void setFecha_registro_usu(String fecha_registro_usu) {
        this.fecha_registro_usu = fecha_registro_usu;
    }

}
*/